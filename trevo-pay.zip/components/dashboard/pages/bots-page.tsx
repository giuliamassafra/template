'use client'

import { Bot, FileText, Plus, Settings2, Split } from 'lucide-react'
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import { bots, formatCompact, formatCurrency, type Bot as BotType } from '@/lib/trevopay-data'
import { PageHeader } from '../page-header'
import { StatusDot } from '../status-badge'
import { useLoading } from '../use-loading'

function BotCard({ bot }: { bot: BotType }) {
  return (
    <Card className="flex flex-col gap-0 overflow-hidden pb-0">
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Bot className="size-5" />
            </span>
            <div className="flex flex-col">
              <span className="font-semibold text-card-foreground">{bot.nome}</span>
              <span className="text-xs text-muted-foreground">{bot.handle}</span>
            </div>
          </div>
          <StatusDot online={bot.status === 'online'} />
        </div>
      </CardHeader>

      <CardContent className="flex flex-col gap-4">
        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground">Leads</span>
            <span className="font-mono text-base font-semibold text-card-foreground">
              {formatCompact(bot.leads)}
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground">Vendas</span>
            <span className="font-mono text-base font-semibold text-card-foreground">
              {formatCompact(bot.vendas)}
            </span>
          </div>
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground">Faturamento</span>
            <span className="font-mono text-base font-semibold text-primary">
              {formatCurrency(bot.faturamento)}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="rounded-md bg-secondary px-2 py-0.5 font-mono">{bot.gateway}</span>
        </div>
      </CardContent>

      {/* Rodapé de card estilizado com ações */}
      <CardFooter className="mt-4 flex items-stretch gap-0 border-t border-border bg-secondary/30 p-0">
        <Button variant="ghost" size="sm" className="h-10 flex-1 rounded-none">
          <Settings2 data-icon="inline-start" />
          Config
        </Button>
        <Separator orientation="vertical" className="h-auto" />
        <Button variant="ghost" size="sm" className="h-10 flex-1 rounded-none">
          <Split data-icon="inline-start" />
          Split
        </Button>
        <Separator orientation="vertical" className="h-auto" />
        <Button variant="ghost" size="sm" className="h-10 flex-1 rounded-none">
          <FileText data-icon="inline-start" />
          Extrato
        </Button>
      </CardFooter>
    </Card>
  )
}

export function BotsPage() {
  const loading = useLoading()

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        title="Gestão de Bots"
        description="Gerencie seus bots, fluxos e performance de conversão."
        action={
          <Button size="sm">
            <Plus data-icon="inline-start" />
            Criar bot
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <Skeleton className="size-10 rounded-lg" />
                    <div className="flex flex-col gap-1.5">
                      <Skeleton className="h-4 w-28" />
                      <Skeleton className="h-3 w-20" />
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="flex flex-col gap-4">
                  <div className="grid grid-cols-3 gap-2">
                    <Skeleton className="h-9" />
                    <Skeleton className="h-9" />
                    <Skeleton className="h-9" />
                  </div>
                  <Skeleton className="h-9 w-full" />
                </CardContent>
              </Card>
            ))
          : bots.map((b) => <BotCard key={b.id} bot={b} />)}
      </div>
    </div>
  )
}
