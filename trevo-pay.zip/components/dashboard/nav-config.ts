import {
  LayoutDashboard,
  Trophy,
  Award,
  LineChart,
  Wallet,
  Users,
  MessagesSquare,
  Handshake,
  Bot,
  Workflow,
  Send,
  Megaphone,
  Plug,
  Radar,
  Link2,
  type LucideIcon,
} from 'lucide-react'

export type PageKey =
  | 'dashboard'
  | 'ranking'
  | 'premiacoes'
  | 'analises'
  | 'financeiro'
  | 'clientes'
  | 'comunidade'
  | 'afiliado'
  | 'bots'
  | 'fluxos'
  | 'remarketing'
  | 'postagens'
  | 'gateways'
  | 'trackeamento'
  | 'biolink'

export type NavItem = {
  key: PageKey
  label: string
  icon: LucideIcon
}

export type NavGroup = {
  label: string
  items: NavItem[]
  /** Adiciona um separador (border-t) acima do grupo para um respiro visual final */
  topSeparator?: boolean
}

export const navGroups: NavGroup[] = [
  {
    label: 'Principal',
    items: [
      { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { key: 'analises', label: 'Análises', icon: LineChart },
    ],
  },
  {
    label: 'Operação',
    items: [
      { key: 'financeiro', label: 'Financeiro', icon: Wallet },
      { key: 'clientes', label: 'Clientes', icon: Users },
      { key: 'comunidade', label: 'Comunidade', icon: MessagesSquare },
      { key: 'afiliado', label: 'Afiliado', icon: Handshake },
    ],
  },
  {
    label: 'Automações',
    items: [
      { key: 'bots', label: 'Bots', icon: Bot },
      { key: 'fluxos', label: 'Fluxos', icon: Workflow },
      { key: 'remarketing', label: 'Remarketing', icon: Megaphone },
      { key: 'postagens', label: 'Postagens', icon: Send },
    ],
  },
  {
    label: 'Integrações',
    items: [
      { key: 'gateways', label: 'Gateways', icon: Plug },
      { key: 'trackeamento', label: 'Trackeamento', icon: Radar },
      { key: 'biolink', label: 'Bio Link', icon: Link2 },
    ],
  },
  {
    label: 'Estratégico',
    topSeparator: true,
    items: [
      { key: 'ranking', label: 'Ranking', icon: Trophy },
      { key: 'premiacoes', label: 'Premiações', icon: Award },
    ],
  },
]

export const pageTitles: Record<PageKey, string> = {
  dashboard: 'Dashboard',
  ranking: 'Ranking',
  premiacoes: 'Premiações',
  analises: 'Análises',
  financeiro: 'Financeiro',
  clientes: 'Base de Clientes',
  comunidade: 'Comunidade',
  afiliado: 'Programa de Afiliados',
  bots: 'Gestão de Bots',
  fluxos: 'Fluxos de Automação',
  remarketing: 'Remarketing',
  postagens: 'Postagens',
  gateways: 'Gateways de Pagamento',
  trackeamento: 'Trackeamento',
  biolink: 'Bio Link',
}
